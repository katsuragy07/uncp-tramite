<?php
include '../../Connections/cn1.php';

$opcion=$_POST['opcion'];
switch ($opcion) {
	case 'ingresar':
	 	$email=$_POST['email'];
	 	$contra=$_POST['pcontra'];	
	 	$sql="SELECT * FROM `vecino` WHERE `email`='$email' and `Password`='$contra'";
		$resultado=mysql_query($sql, $cn1);
		$fila = mysql_fetch_row($resultado);
		$numero=mysql_num_rows($resultado);
		$stado=$fila[8];
		
				if ($numero==1){
					if($stado==0){
						echo 2;
					}else{
						$fila1 = mysql_fetch_assoc($resultado);
						print json_encode($fila1,JSON_UNESCAPED_UNICODE);
					}
				}else{
					echo 0;
				}
		
	break;
	case 'validar':
	
		$nombre=$_POST['nombre'];
		$apellido=$_POST['apellidos'];
		$edad=$_POST['edad'];
		$mail=$_POST['mail'];
		$sexo=$_POST['cbsexo'];

		$sql="SELECT * FROM `vecino` WHERE `email`='$mail'";
		$resultado=mysql_query($sql, $cn1);
		$fila = mysql_fetch_row($resultado);
		$numero=mysql_num_rows($resultado);

		if($numero==0){
			//cuando el correo no existe
			$sql_nuevoexp="SELECT * FROM vecino ORDER BY id DESC limit 1";
			$resultado1=mysql_query($sql_nuevoexp, $cn1);
			$fila1 = mysql_fetch_row($resultado1);
			$resultadonumero1=$fila1[0];
			if(is_null($resultadonumero1)){
				$idnuevo=1;
			}else{
				$idnuevo=$fila1[0]+1;
			}
			
			$codigo=substr(md5(uniqid()), 0, 5);
			$valor=$idnuevo.$codigo;



			$sql2="INSERT INTO `vecino`(`id`, `nombre`, `apellidos`, `sexo`, `edad`, `email`, `Password`, `codigodeactivacion`, `estatus`) VALUES ($idnuevo,'$nombre','$apellido','$sexo',$edad,'$mail',NULL,'$valor',0)";
			$sentencia2=mysql_query($sql2, $cn1);
			if($sentencia2){
 
					$asunto = "Validación de cuenta"; 
					$cuerpo = ' 
						<html> 
							<head> 
   								<title>Municipalidad San Agustin de Cajas</title> 
							</head> 
							<body> 
								<h1>SISTRAM!</h1> 
								<p> 
								<b>Bienvenidos a sistram</b>. Por cuestiones de seguridad usted tendra que activar su cuenta para poder utilizar el sistema. <br>
									Para activar su cuenta aga click en el siguiente enlace <br> 
									<a href="localhost/tramite?key='.$valor.'">Activar cuenta</a> 
								</p>  	
							</body> 
						</html>'; 
						//para el envío en formato HTML 
					$headers = "MIME-Version: 1.0\r\n"; 
					$headers .= "Content-type: text/html; charset=iso-8859-1\r\n"; 
					$headers .= "From: Municipalidad de San Agustin de cajas <j.informatica@uncp.edu.pe>\r\n"; 
					mail($mail,$asunto,$cuerpo,$headers);
					echo 2;
					//cuando todo esta bien
			}else{
				echo 3;
				//error al insertar
			}
		}else{
			echo 4;
			//cuando el correo ya esta en uso;
		}
break;
}
?>

