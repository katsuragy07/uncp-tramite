<!DOCTYPE html>
 
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>SISTRAM - Activacion de Cuenta Via Email</title>
    <link rel="stylesheet" href="css/jquery-ui.css" />
	<link rel="stylesheet" href="css/estilo.css" />
	<link rel="stylesheet" href="css/bootstrap.css" />
    
</head>
<body>
<center>
	<form name="formulario" id="formulario" method="post" action="">
	<table width="50%">
		<tr>
			<td><br/><div id="mensaje"></div></td>
		</tr>
		<tr>
			<td><center>
				<table border=0 class="ventanas" width="70%">
					<tr>
    				  <td colspan="2" class="tabla_ventanas_login" height="10"><legend align="center">::: Activación de cuenta ::: </legend></td>
					</tr>
					<tr><td colspan=2><br/></td></tr>
					<tr>
						<td colspan=2><center>
							<table>
								<tr>
								<td align="right">Contraseña: </td><td><input type="password" class="caja"  name="pas" id="pas" /></td>
								</tr>

								<tr>
								<td align="right">Repetir contraseña: </td><td><input type="password" class="caja"  name="pas1" id="pas1" /></td>
								</tr>
								
								<tr><td colspan=2><center><input type="submit" id="guarda" name="guarda" class="btn btn-sm btn-success" value="Enviar Codigo Activacion" /></center></td></tr>

							</table>
						</center>
						</td>
					</tr>
					
				   </table>
				</center>
			</td>
		</tr>

	</table>
	</form>
   
 </center>
 <script src="js/jquery-1.8.2.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script>
	$(document).ready(function(){
		// Dar el foco al recuadro del código
		$("#Email").focus();	
		// Al hacer click en el botón para guardar
		$("form#formulario").submit(function()
		{
				var User = new Object();
				User.Email     = $('input#Email').val();
				$("#mensaje").append("<div class='modal1'><div class='center1'> <center> <img src='img/gif-load.gif'> Enviando Codigo de Activacion...</center></div></div>");
				var DatosJson = JSON.stringify(User);
				$.post('enviar_codigo.php',
					{ 
						user: DatosJson
					},
					function(data, textStatus) {
						$("#"+data.campo+"").focus();
						$("#mensaje").html(data.error_msg);
					}, 
					"json"		
				);
				return false;
		});
	});
    </script>
</body>
</html>