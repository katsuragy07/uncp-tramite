<?php
header("location: ../urstream/index.php");
?>